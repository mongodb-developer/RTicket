//
//  ContentView.swift
//  RTicket
//
//  Created by Andrew Morgan on 06/05/2022.
//

import SwiftUI

struct ContentView: View {
    @State private var username = ""
    
    var body: some View {
        NavigationView {
            if username == "" {
                LoginView(username: $username)
            } else {
                ProductsView(username: username)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
