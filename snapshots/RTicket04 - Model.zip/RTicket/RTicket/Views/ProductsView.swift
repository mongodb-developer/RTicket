//
//  ProductsView.swift
//  RTicket
//
//  Created by Andrew Morgan on 06/05/2022.
//

import SwiftUI

struct ProductsView: View {
    let username: String
    
    let products = ["MongoDB", "Atlas", "Realm", "Charts", "Compass"]
    
    var body: some View {
        List {
            ForEach(products, id: \.self) { product in
                NavigationLink(destination: Text("\(product) Tickets")) {
                    Text(product)
                }
            }
        }
        .navigationBarTitle("Products", displayMode: .inline)
    }
}

struct ProductsView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ProductsView(username: "Andrew")
        }
    }
}
