//
//  TicketsView.swift
//  RTicket
//
//  Created by Andrew Morgan on 06/05/2022.
//

import SwiftUI
import RealmSwift

struct TicketsView: View {
    @ObservedResults(Ticket.self, sortDescriptor: SortDescriptor(keyPath: "status", ascending: false)) var tickets
    @Environment(\.realm) var realm

    let username: String
    let product: String
    
    @State private var busy = false
    @State private var title = ""
    @State private var details = ""
    
    var body: some View {
        ZStack {
            VStack {
                List {
                    ForEach(tickets) { ticket in
                        TicketView(ticket: ticket)
                    }
                }
                Spacer()
                VStack {
                    TextField("Title", text: $title)
                    TextField("Details", text: $details)
                        .font(.caption)
                    Button("Add Ticket") {
                        addTicket()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(title.isEmpty || busy)
                }
            }
            .padding()
            if busy {
                ProgressView()
            }
        }
        .navigationBarTitle(product, displayMode: .inline)
        .onAppear(perform: subscribe)
        .onDisappear(perform: unsubscribe)
    }
    
    private func addTicket() {
        let ticket = Ticket(product: product, title: title, details: details.isEmpty ? nil : details, author: username)
        $tickets.append(ticket)
        title = ""
        details = ""
    }
    
    private func subscribe() {
        let lastYear = Date(timeIntervalSinceReferenceDate: Date().timeIntervalSinceReferenceDate.rounded() - (60 * 60 * 24 * 365))
        let subscriptions = realm.subscriptions
        
        if subscriptions.first(named: product) == nil {
            busy = true
            subscriptions.write {
                subscriptions.append(QuerySubscription<Ticket>(name: product) { ticket in
                    return ticket.product == product && (
                        ticket.status != .complete || ticket.created > lastYear
                    )
                })
            } onComplete: { error in
                if let error = error {
                    print("Failed to subscribe for \(product): \(error.localizedDescription)")
                }
                busy = false
            }
        }
    }
    
    private func unsubscribe() {
        let subscriptions = realm.subscriptions
        subscriptions.write {
            subscriptions.remove(named: product)
        } onComplete: { error in
            if let error = error {
                print("Failed to unsubscribe for \(product): \(error.localizedDescription)")
            }
        }
    }
}
