//
//  RTicketApp.swift
//  RTicket
//
//  Created by Andrew Morgan on 06/05/2022.
//

import SwiftUI
import RealmSwift

let realmApp = RealmSwift.App(id: "")

@main
struct RTicket2App: SwiftUI.App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
